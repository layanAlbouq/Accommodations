package SWE;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BookingSystem system = new BookingSystem();
        System.out.println("Welcome to Tourist Guide System!");

        System.out.print("\nEnter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        if (system.login(username, password)) {
            User user = system.getUser(username);
            System.out.println("Login successful!");

      
            System.out.print("\nEnter location to search for accommodations: ");
            String location = scanner.nextLine();
            List<Accommodation> results = system.searchAccommodations(location);

            if (results.isEmpty()) {
                System.out.println("No accommodations found in " + location);
            } else {
                System.out.println("Available accommodations:");
                for (int i = 0; i < results.size(); i++) {
                    System.out.println((i + 1) + ". " + results.get(i));
                }

             
                int choice = -1;
                while (true) {
                    System.out.print("\nEnter the number of the accommodation to book: ");
                    if (scanner.hasNextInt()) {
                        choice = scanner.nextInt();
                        if (choice > 0 && choice <= results.size()) {
                            system.bookAccommodation(user, results.get(choice - 1));
                            break;
                        } else {
                            System.out.println("Invalid choice, Please try again");
                        }
                    } else {
                        System.out.println("Please enter a valid number");
                        scanner.next(); 
                    }
                }

        System.out.print("\nWould you like to leave a review? (yes/no): ");
         scanner.nextLine();  
            if (scanner.nextLine().equalsIgnoreCase("yes")) {
            System.out.print("Enter your review: ");
            String review = scanner.nextLine();
            int rating = 0;
             while (true) {
                 System.out.print("Enter your rating (1-5): ");
                 if (scanner.hasNextInt()) {
                 rating = scanner.nextInt();
                 if (rating >= 1 && rating <= 5) {
                 system.leaveReview(user, results.get(choice - 1), review, rating);
                 break;
             } else {
                  System.out.println("Rating must be between 1 and 5");
              }
              } else {
                  System.out.println("Please enter a valid number");
                     scanner.next(); 
                        }
                    }
                }

               
        System.out.println("\nYour booking history:");
           for (Booking booking : user.getBookingHistory()) {
           System.out.println("Accommodation: " + booking.accommodation.name + " | Review: " + booking.review + " | Rating: " + booking.rating);
             }

              
       System.out.print("\nEnter location to check weather: ");
       String weatherLocation = scanner.nextLine();
        System.out.println(system.getWeatherUpdate(weatherLocation));
            }
  } else {
            System.out.println("Login failed");
        }

        scanner.close();
    }
}
