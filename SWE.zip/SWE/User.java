package SWE;

import java.util.ArrayList;
import java.util.List;

public class User {
    String username;
    private String password; 
    private List<Booking> bookingHistory = new ArrayList<>();

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public void addBooking(Booking booking) {
        bookingHistory.add(booking);
    }

    public List<Booking> getBookingHistory() {
        return bookingHistory;
    }
}
